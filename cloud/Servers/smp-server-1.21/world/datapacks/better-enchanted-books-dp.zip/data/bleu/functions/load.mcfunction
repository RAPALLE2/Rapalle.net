    #Tags

    #Finish
tellraw @a ["",{"text":"Alpha","color":"gold"},{"text":" Custom Enchanted Book Textures","color":"dark_green"},{"text":" has been loaded!","color":"yellow"},{"text":"\n"},{"text":"--Created By:","color":"yellow"},{"text":" AlphaBleu","color":"gold"},{"text":"--","color":"yellow"},{"text":"\n "}]